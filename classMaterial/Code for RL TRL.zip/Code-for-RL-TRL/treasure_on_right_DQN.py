"""
A simple example for Reinforcement Learning using table lookup Q-learning method.
An agent "o" is on the left of a 1 dimensional world, the treasure is on the rightmost location.
Run this program and to see how the agent will improve its strategy of finding the treasure.

View more on my tutorial page: https://morvanzhou.github.io/tutorials/
"""

import numpy as np
import pandas as pd
import time

from DQN_modified import DeepQNetwork

np.random.seed(2)  # reproducible


N_STATES = 6   # the length of the 1 dimensional world
N_FEATURES = 1   # number of features 
N_ACTIONS = 2   # number of actions 
#ACTIONS = ['left', 'right']     # available actions
ACTIONS = [0, 1]     # available actions
EPSILON = 0.9   # greedy police
ALPHA = 0.1     # learning rate
GAMMA = 0.9    # discount factor
MAX_EPISODES = 13   # maximum episodes
FRESH_TIME = 0.3    # fresh time for one 


def build_q_table(n_states, actions):
    table = pd.DataFrame(
        np.zeros((n_states, len(actions))),     # q_table initial values
        columns=actions,    # actions's name
    )
    # print(table)    # show table
    return table


def choose_action(state, q_table):
    # This is how to choose an action
    state_actions = q_table.iloc[state, :]
    if (np.random.uniform() > EPSILON) or (state_actions.all() == 0):  # act non-greedy or state-action have no value
        action_name = np.random.choice(ACTIONS)
    else:   # act greedy
        action_name = state_actions.argmax()
    return action_name


def get_env_feedback(S, A):
    # This is how agent will interact with the environment
    done = 0
    if A == 1:    # move right
        if S == N_STATES - 2:   # terminate
            S_ = 77
            R = 1
            done = 1
        else:
            S_ = S + 1
            R = 0
    else:   # move left
        R = 0
        if S == 0:
            S_ = S  # reach the wall
        else:
            S_ = S - 1
    return S_, R, done


def update_env(S, episode, step_counter):
    # This is how environment be updated
    env_list = ['-']*(N_STATES-1) + ['T']   # '---------T' our environment
    if S == 77:
        interaction = 'Episode %s: total_steps = %s' % (episode+1, step_counter)
        print('\r{}'.format(interaction))
        time.sleep(2)
        print('\r                                ')
    else:
        env_list[S] = 'o'
        interaction = ''.join(env_list)
        print('\r{}'.format(interaction))
        time.sleep(FRESH_TIME)


def rl():
    # main part of RL loop
    RL = DeepQNetwork(N_ACTIONS, N_FEATURES,
                      learning_rate=0.01,
                      reward_decay=0.9,
                      e_greedy=0.9,
                      replace_target_iter=200,
                      memory_size=500,
                      # output_graph=True
                      )
    for episode in range(MAX_EPISODES):
        step_counter = 0
        S = 0
        is_terminated = False
        update_env(S, episode, step_counter)
        while not is_terminated:
            A = RL.choose_action(S)
            S_, R, done = get_env_feedback(S, A)  # take action & get next state and reward

            RL.store_transition(S,A,R,S_)

            if (step_counter > 200) and (step_counter % 5 == 0):
                RL.learn()
            S = S_  # move to next state

            if done:
              break

            update_env(S, episode, step_counter+1)
            step_counter += 1
            if S_ == 77:
              is_terminated = True


if __name__ == "__main__":
    rl()
    print('\r\nEnd of Running:\n')
